from django.contrib import admin
from .models import Meditation

admin.site.register(Meditation)