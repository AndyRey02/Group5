from django.contrib import admin
from .models import Meditation, About

admin.site.register(Meditation)
admin.site.register(About)